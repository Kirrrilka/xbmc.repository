# -*- coding: utf-8 -*-

from xbmcswift2 import Plugin

plugin = Plugin()
